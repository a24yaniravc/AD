public enum Hechizo {
    ADIVINACION,
    NECROMANCIA,
    PIROMANCIA,
    INVOCACION
}
