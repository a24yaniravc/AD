public interface ComparadorNombre {
  
}