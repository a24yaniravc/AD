import java.io.File;

public interface InnerFiltrarNombre {
    public boolean accept(File dir, String name);
}