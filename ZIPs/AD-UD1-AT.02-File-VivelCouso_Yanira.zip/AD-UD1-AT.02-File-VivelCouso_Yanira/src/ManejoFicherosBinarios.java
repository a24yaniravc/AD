public class ManejoFicherosBinarios {
    public static void main(String[] args) {
        String rutaOriginal = "origen.bin";
        String rutaNueva = "destino.bin";

        // Crear ficheros
        FicheroBinario origen = new FicheroBinario(rutaOriginal);
        FicheroBinario destino = new FicheroBinario(rutaNueva);

        // Escribir en el fichero de origen
        origen.escribir("ESTE ES EL TEXTO DE ORIGEN.");

        // Mostrar el contenido
        origen.leer();

        // Copiar el contenido
        System.out.println("Copiando información de " + rutaOriginal + " a " + rutaNueva + "..." );
        origen.copiar(destino);

        // Mostrar el contenido del fichero destino para comprobar
        destino.leer();
    }
}
