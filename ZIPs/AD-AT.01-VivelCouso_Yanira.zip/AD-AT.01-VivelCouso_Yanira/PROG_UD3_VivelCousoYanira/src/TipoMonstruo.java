public enum TipoMonstruo {
    OGRO,
    TROLL,
    ESPECTRO
}