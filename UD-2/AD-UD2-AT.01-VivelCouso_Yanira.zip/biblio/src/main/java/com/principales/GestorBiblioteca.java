package com.principales;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.conexiones.MySQLConnection;

public class GestorBiblioteca {
    private final boolean createAnyways;

    // Constructor
    public GestorBiblioteca(boolean createAnyways) {
        this.createAnyways = createAnyways;
    }

    public void create(String DB) throws SQLException {
        MySQLConnection mysqlConnection = new MySQLConnection();
        try (Connection connection = mysqlConnection.getConnection();
             Statement statement = connection.createStatement()) {

            if (createAnyways) {
                statement.executeUpdate("DROP DATABASE IF EXISTS " + DB);
                System.out.println("> Base de datos borrada");

                statement.executeUpdate("CREATE DATABASE " + DB);
                System.out.println("> Base de datos creada");
            } else {
                statement.executeUpdate("CREATE DATABASE IF NOT EXISTS " + DB);
            }
        }
    }
}