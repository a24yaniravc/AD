package com.principales;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;

public class GestorLibros {
    private Connection conn;

    // Constructor
    public GestorLibros(Connection conn) throws SQLException {
        this.conn = conn;
        Statement stmt = conn.createStatement();
        // Crear tabla libros si no existe
        String sqlCreate = "CREATE TABLE IF NOT EXISTS libros (" +
                "ISBN VARCHAR(20) NOT NULL," +
                "titulo VARCHAR(100) NOT NULL," +
                "autor VARCHAR(100) NOT NULL," +
                "anio_publicacion INT NOT NULL," +
                "PRIMARY KEY (ISBN)" +
                ")";
        stmt.executeUpdate(sqlCreate);
    }

    // Métodos para gestionar libros

    // Crear un nuevo libro
    public void addLibro(String isbn, String titulo, String autor, int anioPublicacion) throws SQLException {
        String sqlInsert = "INSERT INTO libros (ISBN, titulo, autor, anio_publicacion) VALUES (?, ?, ?, ?)";
        
        try (var pstmt = conn.prepareStatement(sqlInsert)) {
            pstmt.setString(1, isbn);
            pstmt.setString(2, titulo);
            pstmt.setString(3, autor);
            pstmt.setInt(4, anioPublicacion);
            pstmt.executeUpdate();
            System.out.println("Libro creado exitosamente.");
        }
    }

    // Consultas
    // Obtener todos los libros
    public void getLibros() throws SQLException {
        String sqlSelect = "SELECT * FROM libros";
        
        try (var statement = conn.createStatement();
             var rs = statement.executeQuery(sqlSelect)) {
            while (rs.next()) {
                System.out.println("ISBN: " + rs.getString("ISBN") +
                                   ", Titulo: " + rs.getString("titulo") +
                                   ", Autor: " + rs.getString("autor") +
                                   ", Año de Publicación: " + rs.getInt("anio_publicacion"));
            }
        }
    }

    // Obtener libro de un autor/a específico
    public void getLibrosByAutor(String autor) throws SQLException {
        String sqlSelect = "SELECT * FROM libros WHERE autor = ?";
        try (var statement = conn.prepareStatement(sqlSelect)) {
            statement.setString(1, autor);
            try (var rs = statement.executeQuery()) {
                while (rs.next()) {
                    System.out.println("ISBN: " + rs.getString("ISBN") +
                                       ", Titulo: " + rs.getString("titulo") +
                                       ", Autor: " + rs.getString("autor") +
                                       ", Año de Publicación: " + rs.getInt("anio_publicacion"));
                }
            }
        }
    }

    // Obtener libros posteriores a un año específico
    public void getLibrosByAnio(int anioPublicacion) throws SQLException {
        String sqlSelect = "SELECT * FROM libros WHERE anio_publicacion > ?";
        try (var statement = conn.prepareStatement(sqlSelect)) {
            statement.setInt(1, anioPublicacion);
            try (var rs = statement.executeQuery()) {
                while (rs.next()) {
                    System.out.println("ISBN: " + rs.getString("ISBN") +
                                        ", Titulo: " + rs.getString("titulo") +
                                        ", Autor: " + rs.getString("autor") +
                                        ", Año de Publicación: " + rs.getInt("anio_publicacion"));
                }
            }
        }
    }

    // Modificar un libro
    // Modificar titulo
    public void updateTitulo(String isbn, String nuevoTitulo) throws SQLException {
        String sqlUpdate = "UPDATE libros SET titulo = ? WHERE ISBN = ?";
        
        try (var statement = conn.prepareStatement(sqlUpdate)) {
            statement.setString(1, nuevoTitulo);
            statement.setString(2, isbn);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Título actualizado exitosamente.");
            } else {
                System.out.println("No se encontró el libro con el ISBN proporcionado.");
            }
        }
    }

    // Modificar autor/a
    public void updateAutor(String isbn, String nuevoAutor) throws SQLException {
        String sqlUpdate = "UPDATE libros SET autor = ? WHERE ISBN = ?";
        
        try (var statement = conn.prepareStatement(sqlUpdate)) {
            statement.setString(1, nuevoAutor);
            statement.setString(2, isbn);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Autor actualizado exitosamente.");
            } else {
                System.out.println("No se encontró el libro con el ISBN proporcionado.");
            }
        }
    }

    // Modificar año de publicación
    public void updateAnioPublicacion(String isbn, int nuevoAnio) throws SQLException {
        String sqlUpdate = "UPDATE libros SET anio_publicacion = ? WHERE ISBN = ?";
        try (var statement = conn.prepareStatement(sqlUpdate)) {
            statement.setInt(1, nuevoAnio);
            statement.setString(2, isbn);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Año de publicación actualizado exitosamente.");
            } else {
                System.out.println("No se encontró el libro con el ISBN proporcionado.");
            }
        }
    }

    // Eliminar un libro
    public void deleteLibro(String isbn) throws SQLException {
        String sqlDelete = "DELETE FROM libros WHERE ISBN = ?";
        try (var statement = conn.prepareStatement(sqlDelete)) {
            statement.setString(1, isbn);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Libro eliminado exitosamente.");
            } else {
                System.out.println("No se encontró el libro con el ISBN proporcionado.");
            }
        }
    }

    // Eliminar libros anteriores a un año específico
    public void deleteLibrosByAnio(int anioPublicacion) throws SQLException {
        String sqlDelete = "DELETE FROM libros WHERE anio_publicacion < ?";
        try (var statement = conn.prepareStatement(sqlDelete)) {
            statement.setInt(1, anioPublicacion);
            int rowsAffected = statement.executeUpdate();
            System.out.println(rowsAffected + " libros eliminados que eran anteriores al año " + anioPublicacion + ".");
        }
    }

    // CleanLibros
    public void cleanLibros() throws SQLException {
        String sqlDeleteAll = "DELETE FROM libros";
        try (var statement = conn.createStatement()) {
            int rowsAffected = statement.executeUpdate(sqlDeleteAll);
            System.out.println("Se han eliminado " + rowsAffected + " libros de la base de datos.");
        }
    }
}